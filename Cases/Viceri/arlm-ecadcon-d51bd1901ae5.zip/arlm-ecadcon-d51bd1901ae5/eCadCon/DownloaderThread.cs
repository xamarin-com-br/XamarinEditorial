using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System.ComponentModel;

namespace eCadCon
{
	public class DownloaderThread : Java.Lang.Thread
	{

		public const int DOWNLOAD_BUFFER_SIZE = 4096;

		private FileDownloader parentActivity;
		private string downloadUrl;
		private long totalRead = 0;
		private long totalToRead = 0;
		private bool download;

		public DownloaderThread(FileDownloader inParentActivity, String inUrl, bool download = true)
		{
			downloadUrl = "";
			if(inUrl != null)
			{
				downloadUrl = inUrl;
			}
			parentActivity = inParentActivity;
			this.download = download;
		}

		public override void Run()
		{
			WebClient webClient; 
			Message msg;

			msg = Message.Obtain (parentActivity.activityHandler,
			                     FileDownloader.MESSAGE_CONNECTING_STARTED,
			                     0, 0, new Java.Lang.String(downloadUrl));
			parentActivity.activityHandler.SendMessage (msg);

			using (webClient = new WebClient()) {
				webClient.DownloadFileCompleted += new AsyncCompletedEventHandler (DownloadCompleted);
				webClient.DownloadProgressChanged += new DownloadProgressChangedEventHandler (DownloadProgressChanged);
				webClient.UploadFileCompleted += new UploadFileCompletedEventHandler (UploadCompleted);
				webClient.UploadProgressChanged += new UploadProgressChangedEventHandler (UploadProgressChanged);

				try {
					Uri URL;

					if (!downloadUrl.StartsWith("http://", StringComparison.OrdinalIgnoreCase))
						URL = new Uri("http://" + downloadUrl);
					else
						URL = new Uri(downloadUrl);

					if (download)
					{
						webClient.DownloadFileAsync(URL, Repository.db_path + ".tmp");
					} else {
						webClient.UploadFileAsync(URL, Repository.db_path);
					}
				}  catch (Exception) {
					String errMsg = parentActivity.GetString (Resource.String.error_message_general);
					msg = Message.Obtain (parentActivity.activityHandler,
					                      FileDownloader.MESSAGE_ENCOUNTERED_ERROR,
					                      0, 0,  new Java.Lang.String(errMsg));
					parentActivity.activityHandler.SendMessage (msg); 
				}
			}
		}

		void DownloadCompleted (object sender, AsyncCompletedEventArgs e)
		{
			Message msg;

			if (e.Cancelled)
			{
				File.Delete(Repository.db_path + ".tmp");
				return;
			}

			if (e.Error != null) {
				String errMsg = parentActivity.GetString (Resource.String.error_message_general);
				msg = Message.Obtain (parentActivity.activityHandler,
				                      FileDownloader.MESSAGE_ENCOUNTERED_ERROR,
				                      0, 0, new Java.Lang.String(errMsg));
				parentActivity.activityHandler.SendMessage (msg); 
				return;
			}

			File.Delete (Repository.db_path);
			File.Move (Repository.db_path + ".tmp", Repository.db_path);

			msg = Message.Obtain (parentActivity.activityHandler,
			                      FileDownloader.MESSAGE_DOWNLOAD_COMPLETE);
			parentActivity.activityHandler.SendMessage (msg);

		}

		void UploadCompleted (object sender, UploadFileCompletedEventArgs e)
		{
			Message msg;

			if (e.Cancelled)
			{
				return;
			}

			if (e.Error != null) {
				String errMsg = parentActivity.GetString (Resource.String.error_message_general);
				msg = Message.Obtain (parentActivity.activityHandler,
				                      FileDownloader.MESSAGE_ENCOUNTERED_ERROR,
				                      0, 0, new Java.Lang.String(errMsg));
				parentActivity.activityHandler.SendMessage (msg); 
				return;
			}

			msg = Message.Obtain (parentActivity.activityHandler,
			                      FileDownloader.MESSAGE_UPLOAD_COMPLETE,
			                      0, 0, new Java.Lang.String(System.Text.Encoding.UTF8.GetString(e.Result)));
			parentActivity.activityHandler.SendMessage (msg);

		}


		void DownloadProgressChanged (object sender, DownloadProgressChangedEventArgs e)
		{
			Message msg;

			if (totalToRead == 0) {
				totalToRead = e.TotalBytesToReceive;
				int totalToReadinKB = (int) totalToRead / 1024;
				msg = Message.Obtain (parentActivity.activityHandler,
				                      FileDownloader.MESSAGE_DOWNLOAD_STARTED,
				                      totalToReadinKB, 0,  new Java.Lang.String(Repository.db_file));
				parentActivity.activityHandler.SendMessage (msg);

			}

			totalRead += e.BytesReceived;
			int totalReadInKB = (int) totalRead / 1024;
			msg = Message.Obtain (parentActivity.activityHandler,
			                      FileDownloader.MESSAGE_UPDATE_PROGRESS_BAR,
			                      totalReadInKB, 0);
			parentActivity.activityHandler.SendMessage (msg);
		}

		void UploadProgressChanged (object sender, UploadProgressChangedEventArgs e)
		{
			Message msg;

			if (totalToRead == 0) {
				totalToRead = e.TotalBytesToReceive;
				int totalToReadinKB = (int) totalToRead / 1024;
				msg = Message.Obtain (parentActivity.activityHandler,
				                      FileDownloader.MESSAGE_UPLOAD_STARTED,
				                      totalToReadinKB, 0,  new Java.Lang.String(Repository.db_file));
				parentActivity.activityHandler.SendMessage (msg);

			}

			totalRead += e.BytesReceived;
			int totalReadInKB = (int) totalRead / 1024;
			msg = Message.Obtain (parentActivity.activityHandler,
			                      FileDownloader.MESSAGE_UPDATE_PROGRESS_BAR,
			                      totalReadInKB, 0);
			parentActivity.activityHandler.SendMessage (msg);
		}
	}
}

