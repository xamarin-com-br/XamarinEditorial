using System;
using Android.App;

namespace eCadCon
{
	public class TabListener<T> : Java.Lang.Object, ActionBar.ITabListener
		where T: Fragment, new()
	{
		private T _fragment;
		private bool added = false;

		public TabListener()
		{
			_fragment = new T();
		}

		protected TabListener(T fragment)
		{
			_fragment = fragment;
		}

		public void OnTabReselected(ActionBar.Tab tab, FragmentTransaction ft)
		{

		}

		public void OnTabSelected(ActionBar.Tab tab, FragmentTransaction ft)
		{
			if (!added) {
				_fragment = new T ();
				ft.Add(Resource.Id.container,_fragment, typeof(T).FullName);
				//added = true;
			} else {
				ft.Attach (_fragment);
			}
		}

		public void OnTabUnselected(ActionBar.Tab tab, FragmentTransaction ft)
		{
			if (!added) {
				ft.Remove (_fragment);
			} else {
				ft.Detach (_fragment);
			}
		}
	}
}

