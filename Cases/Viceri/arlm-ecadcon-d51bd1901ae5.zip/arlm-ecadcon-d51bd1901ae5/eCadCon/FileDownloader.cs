using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Content.PM;

namespace eCadCon
{
	[Activity (Label = "DownloadDialog", ExcludeFromRecents = true)]			
	public class FileDownloader : Activity
	{
		public const int MESSAGE_DOWNLOAD_STARTED = 1000;
		public const int MESSAGE_DOWNLOAD_COMPLETE = 1001;
		public const int MESSAGE_UPDATE_PROGRESS_BAR = 1002;
		public const int MESSAGE_DOWNLOAD_CANCELED = 1003;
		public const int MESSAGE_CONNECTING_STARTED = 1004;
		public const int MESSAGE_ENCOUNTERED_ERROR = 1005;
		public const int MESSAGE_UPLOAD_STARTED = 1006;
		public const int MESSAGE_UPLOAD_COMPLETE = 1007;
		public const int MESSAGE_UPLOAD_CANCELED = 1008;

		private static FileDownloader thisActivity;
		private static Java.Lang.Thread downloaderThread;
		private static ProgressDialog progressDialog;
		private static bool download = true;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			thisActivity = this;
			downloaderThread = null;
			progressDialog = null;
			download = (Intent.GetStringExtra ("type") ?? "download") == "download";
			ShowDialog (0);
		}

		public Handler activityHandler = new Handler();

		private void OkClicked(object sender, DialogClickEventArgs args)
		{
			var dialog = (AlertDialog) sender;
			var urlInputField = (EditText)dialog.FindViewById(Resource.Id.url_input);

			String urlInput = String.IsNullOrEmpty(urlInputField.Text) ? urlInputField.Hint : urlInputField.Text;

			downloaderThread = new DownloaderThread(thisActivity, urlInput, download);
			downloaderThread.Start();
		}

		private void CancelClicked(object sender, DialogClickEventArgs args)
		{
			Finish ();
		}

		protected override Dialog OnCreateDialog (int id)
		{
			switch(id)
			{
			case 0:
				var customView = LayoutInflater.Inflate (Resource.Layout.DownloadDialog, null);
				var urlInputField = (EditText) customView.FindViewById(Resource.Id.url_input);
				if (download) {
					//urlInputField.Hint = "http://posttestserver.com/files/2013/07/23/f_22.50.13477368897";
				} else {
					urlInputField.Hint = "http://posttestserver.com/post.php";
				}

				var builder = new AlertDialog.Builder (this);
				builder.SetView (customView);
				if (download) {
					builder.SetTitle ("Baixar Banco de Dados");
					builder.SetMessage ("Digite o endereço de onde baixar");
				} else {
					builder.SetTitle ("Enviar Banco de Dados");
					builder.SetMessage ("Digite o endereço para enviar");
				}
				builder.SetPositiveButton("Enviar", OkClicked);
				builder.SetNegativeButton("Cancelar", CancelClicked);

				return builder.Create();
			}

			return base.OnCreateDialog (id);
		}

		public static void dismissCurrentProgressDialog()
		{
			if(progressDialog != null)
			{
				progressDialog.Hide();
				progressDialog.Dismiss();
				progressDialog = null;
			}
		}

		public static void displayMessage(String message)
		{
			if(message != null)
			{
				Toast.MakeText(thisActivity, message, ToastLength.Short).Show();
			}
		}

		public class Handler : Android.OS.Handler {
			void Started (Message msg, int maxValue)
			{
				String fileName = (String)msg.Obj;
				String pdTitle = download ? thisActivity.GetString (Resource.String.progress_dialog_title_downloading) :
					thisActivity.GetString (Resource.String.progress_dialog_title_uploading);
				String pdMsg = download ? thisActivity.GetString (Resource.String.progress_dialog_message_prefix_downloading) :
					thisActivity.GetString (Resource.String.progress_dialog_message_prefix_uploading);
				pdMsg += " " + fileName;
				dismissCurrentProgressDialog ();
				progressDialog = new ProgressDialog (thisActivity);
				progressDialog.SetTitle (pdTitle);
				progressDialog.SetMessage (pdMsg);
				progressDialog.SetProgressStyle (ProgressDialogStyle.Horizontal);
				progressDialog.Progress = 0;
				progressDialog.Max = maxValue;
				Message newMsg = download ? Message.Obtain (this, MESSAGE_DOWNLOAD_CANCELED) :
					Message.Obtain (this, MESSAGE_UPLOAD_CANCELED);
				progressDialog.SetCancelMessage (newMsg);
				progressDialog.SetCancelable (true);
				progressDialog.Show ();
			}

			public override void HandleMessage(Message msg)
			{
				switch(msg.What)
				{
					case MESSAGE_UPDATE_PROGRESS_BAR:
					if(progressDialog != null)
					{
						int currentProgress = msg.Arg1;
						progressDialog.Progress = currentProgress;
					}
					break;

					case MESSAGE_CONNECTING_STARTED:
					if(msg.Obj != null && msg.Obj is Java.Lang.String)
					{
						String url = (String) msg.Obj;

						if(url.Length > 16)
						{
							String tUrl = url.Substring(0, 15);
							tUrl += "...";
							url = tUrl;
						}
						String pdTitle = thisActivity.GetString(Resource.String.progress_dialog_title_connecting);
						String pdMsg = thisActivity.GetString(Resource.String.progress_dialog_message_prefix_connecting);
						pdMsg += " " + url;

						dismissCurrentProgressDialog();
						progressDialog = new ProgressDialog(thisActivity);
						progressDialog.SetTitle(pdTitle);
						progressDialog.SetMessage(pdMsg);
						progressDialog.SetProgressStyle(ProgressDialogStyle.Spinner);
						progressDialog.Indeterminate = true;

						Message newMsg = download ? Message.Obtain(this, MESSAGE_DOWNLOAD_CANCELED) :
							Message.Obtain(this, MESSAGE_UPLOAD_CANCELED);
						progressDialog.SetCancelMessage(newMsg);
						progressDialog.Show();
					}
					break;

					case MESSAGE_DOWNLOAD_STARTED:
					case MESSAGE_UPLOAD_STARTED:
					if(msg.Obj != null && msg.Obj is Java.Lang.String)
					{
						int maxValue = msg.Arg1;
						Started (msg, maxValue);

					}
					break;

				case MESSAGE_DOWNLOAD_COMPLETE:
				case MESSAGE_UPLOAD_COMPLETE:
					dismissCurrentProgressDialog ();
					string completeMessage = download ? thisActivity.GetString (Resource.String.user_message_download_complete) :
						thisActivity.GetString (Resource.String.user_message_upload_complete);
					displayMessage (completeMessage);
					if (download) {
						var builder = new AlertDialog.Builder (thisActivity);
						builder.SetTitle ("Download Completo");
						builder.SetMessage ("Clique no ícone na barra te título para atualizar os dados");
						builder.SetPositiveButton ("OK", (s, e) => {
							thisActivity.Finish (); });
						builder.Create ().Show ();
					} else {
						if (msg.Obj != null && msg.Obj is Java.Lang.String) {
							String errorMessage = (String)msg.Obj;
							var builder = new AlertDialog.Builder (thisActivity);
							builder.SetTitle ("Retorno");
							builder.SetMessage (errorMessage);
							builder.SetPositiveButton ("OK", (s, e) => {
								thisActivity.Finish (); });
							builder.Create ().Show ();
						} else {
							thisActivity.Finish ();
						}
					}
					break;

					case MESSAGE_DOWNLOAD_CANCELED:
					case MESSAGE_UPLOAD_CANCELED:
					if(downloaderThread != null)
					{
						downloaderThread.Interrupt();
					}
					dismissCurrentProgressDialog();
					string cancelMessage = download ? thisActivity.GetString (Resource.String.user_message_download_canceled) :
						thisActivity.GetString (Resource.String.user_message_upload_canceled);
					displayMessage(cancelMessage);
					thisActivity.Finish();
					break;

					case MESSAGE_ENCOUNTERED_ERROR:
					if(msg.Obj != null && msg.Obj is Java.Lang.String)
					{
						String errorMessage = (String) msg.Obj;
						dismissCurrentProgressDialog();
						displayMessage(errorMessage);
					}
					thisActivity.Finish();
					break;

					default:
					break;
				}
			}
		}	}
}

