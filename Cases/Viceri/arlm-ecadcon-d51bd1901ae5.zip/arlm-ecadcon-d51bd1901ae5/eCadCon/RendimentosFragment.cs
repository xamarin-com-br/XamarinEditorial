using System;
using Android.App;
using Android.Views;
using Android.Widget;
using System.Globalization;

namespace eCadCon
{
	public class RendimentosFragment : Fragment
	{
		private Spinner income_type;
		private Spinner contract_type;
		private Spinner work_type;
		private CheckBox bolsa_familia;
		private EditText bolsa_familia_number;
		private TextView contract_date;
		private TextView company;
		private TextView position;
		private TextView minimum_salaries;
		private CheckBox inss;

		private DateTime date;
		private Activity1 main;

		const int RENDIMENTO_DIALOG_ID = 1;

		public override Android.Views.View OnCreateView(Android.Views.LayoutInflater inflater,
		                                                Android.Views.ViewGroup container, Android.OS.Bundle savedInstanceState)
		{
			View view = inflater.Inflate(Resource.Layout.RendimentosFragment, container, false);

			contract_date = view.FindViewById<TextView> (Resource.Id.contract_date); 

			contract_date.Text = Repository.Person.ContractDate == DateTime.MinValue  ? 
				"" : Repository.Person.ContractDate.ToString ("dd/MM/yyyy");

			contract_date.Click += delegate {
				Activity.ShowDialog (RENDIMENTO_DIALOG_ID);
			};

			income_type = view.FindViewById<Spinner> (Resource.Id.income_type);

			var income_type_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                              Resource.Array.income_type_array,
			                                                             Resource.Id.txt_nothing_selected, income_type.Prompt);
			income_type.Adapter = income_type_adapter;
			income_type.SetSelection ((int) Repository.Person.IncomeType);

			contract_type = view.FindViewById<Spinner> (Resource.Id.contract_type);

			var contract_type_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                              Resource.Array.contract_type_array,
			                                                               Resource.Id.txt_nothing_selected, contract_type.Prompt);
			contract_type.Adapter = contract_type_adapter;
			contract_type.SetSelection ((int) Repository.Person.ContractType);

			work_type = view.FindViewById<Spinner> (Resource.Id.work_type);

			var work_type_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                              Resource.Array.work_type_array,
			                                                           Resource.Id.txt_nothing_selected, work_type.Prompt);
			work_type.Adapter = work_type_adapter;
			work_type.SetSelection ((int) Repository.Person.WorkType);

			bolsa_familia = view.FindViewById<CheckBox> (Resource.Id.bolsa_familia);
			bolsa_familia.Checked = Repository.Person.BolsaFamilia;

			bolsa_familia_number = view.FindViewById<EditText> (Resource.Id.bolsa_familia_number);
			bolsa_familia_number.Text = Repository.Person.BolsaFamiliaNumber;
			bolsa_familia_number.Visibility = bolsa_familia.Checked ? ViewStates.Visible  : ViewStates.Gone;

			bolsa_familia.CheckedChange += (sender, e) => { 
				bolsa_familia_number.Visibility = bolsa_familia.Checked ? ViewStates.Visible  : ViewStates.Gone;
			};

			inss = view.FindViewById<CheckBox> (Resource.Id.inss);
			inss.Checked = Repository.Person.Inss;

			company = view.FindViewById<EditText> (Resource.Id.company);
			company.Text = Repository.Person.Company;

			position = view.FindViewById<EditText> (Resource.Id.position);
			position.Text = Repository.Person.Position;

			minimum_salaries = view.FindViewById<EditText> (Resource.Id.minimum_salaries);
			minimum_salaries.Text = Repository.Person.MinimumSalaries;

			return view;
		}

		public override void OnAttach (Activity activity)
		{
			base.OnAttach (activity);

			main = activity as Activity1;

			main.OnContractDateSet = OnContractDateSet;
			main.OnGetContractDate = GetDate;
			main.OnSave = Save;
		}

		void Save ()
		{
			Repository.Person.ContractDate = GetDate ();
			Repository.Person.Company = company.Text;
			Repository.Person.Position = position.Text;
			Repository.Person.MinimumSalaries = minimum_salaries.Text;
			Repository.Person.IncomeType = income_type.SelectedItemId + 1;
			Repository.Person.ContractType = contract_type.SelectedItemId + 1;
			Repository.Person.WorkType = work_type.SelectedItemId + 1;
			Repository.Person.BolsaFamilia = bolsa_familia.Checked;
			Repository.Person.BolsaFamiliaNumber = bolsa_familia_number.Text;
			Repository.Person.Inss = inss.Checked;
			Repository.Person.Save ();
		}

		public override void OnDestroyView ()
		{
			Save ();

			main.OnContractDateSet = null;
			main.OnGetContractDate = null;
			main.OnSave = null;

			base.OnDestroyView ();
		}

		public void OnContractDateSet (object sender, DatePickerDialog.DateSetEventArgs e)
		{
			contract_date.Text = e.Date.ToString ("dd/MM/yyyy");
		}

		public DateTime GetDate() {
			if (string.IsNullOrEmpty (contract_date.Text)) {
				date = DateTime.Now;
			} else {
				date = DateTime.ParseExact (contract_date.Text, "dd/MM/yyyy", DateTimeFormatInfo.CurrentInfo);
			}
			return date;
		}
	}
}

