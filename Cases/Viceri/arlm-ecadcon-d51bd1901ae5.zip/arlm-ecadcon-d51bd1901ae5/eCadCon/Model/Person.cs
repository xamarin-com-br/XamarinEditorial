using System;
using System.Collections.Generic;
using System.Linq;
using SQLite;
using Mono.Data.Sqlite;

namespace eCadCon
{
	public class Person
	{
		[PrimaryKey, AutoIncrement]
		public long Id { get; set; }

		// Cadastro
		public string Name { get; set; }
		public long Sex { get; set; }
		public long Color { get; set; }
		public DateTime Birthdate { get; set; }
		public string Street { get; set; }
		public string Number { get; set; }
		public string Neighborhood { get; set; }
		public string Cep { get; set; }

		// Pessoais
		public string ReferenceName { get; set; }
		public long Relationship { get; set; }
		public string FatherName { get; set; }
		public string MotherName { get; set; }
		public string Rg { get; set; }
		public string RgExpeditioner { get; set; }
		public string Cpf { get; set; }
		public string VoterDocument { get; set; }
		public string VotingZone { get; set; }
		public string VotingSession { get; set; }
		public string Ctps { get; set; }
		public string CtpsSeries { get; set; }
		public string CtpsUf { get; set; }
		public string Email { get; set; }
		public string Phone1 { get; set; }
		public string Phone2 { get; set; }
		public string Phone3 { get; set; }
		public string Nationality { get; set; }
		public string Uf { get; set; }
		public string City { get; set; }
		public long RelationshipStatus { get; set; }

		// Ocupação
		public string OcupationLevel { get; set; }
		public string Company { get; set; }
		public DateTime ContractDate { get; set; }
		public string Position { get; set; }
		public string MinimumSalaries { get; set; }
		public long IncomeType { get; set; }
		public long ContractType { get; set; }
		public long WorkType { get; set; }
		public bool Inss { get; set; }
		public bool BolsaFamilia { get; set; }
		public string BolsaFamiliaNumber { get; set; }

		// Educação
		public long Education { get; set; }
		public string ConclusionGrade { get; set; }

		//Moradia
		public long Rent { get; set; }
		public string RentValue { get; set; }
		public string Iptu { get; set; }
		public long HouseLevel { get; set; }
		public long HouseType { get; set; }
		public long ComfortLevel { get; set; }
		public string Rooms { get; set; }
		public string Bedrooms { get; set; }
		public string Zoning { get; set; }
		public bool Water { get; set; }
		public bool Bathroom { get; set; }
		public bool Floor { get; set; }
		public bool WaterTreatment { get; set; }
		public bool GarbageTreatment { get; set; }
		public long FloorMaterial { get; set; }
		public long WallMaterial { get; set; }

		// Saúde
		public string HealthType { get; set; }
		public string HealthClass { get; set; }
		public DateTime HealthStartDate { get; set; }
		public DateTime HealthEndDate { get; set; }

		public Person ()
		{
			this.Name = string.Empty;
			this.Street = string.Empty;
			this.Number = string.Empty;
			this.Neighborhood = string.Empty;
			this.Cep = string.Empty;
			this.ReferenceName = string.Empty;
			this.FatherName = string.Empty;
			this.MotherName = string.Empty;
			this.Rg = string.Empty;
			this.RgExpeditioner = string.Empty;
			this.Cpf = string.Empty;
			this.VoterDocument = string.Empty;
			this.VotingZone = string.Empty;
			this.VotingSession = string.Empty;
			this.Ctps = string.Empty;
			this.CtpsSeries = string.Empty;
			this.CtpsUf = string.Empty;
			this.Email = string.Empty;
			this.Phone1 = string.Empty;
			this.Phone2 = string.Empty;
			this.Phone3 = string.Empty;
			this.Nationality = string.Empty;
			this.Uf = string.Empty;
			this.City = string.Empty;
			this.OcupationLevel = string.Empty;
			this.Company = string.Empty;
			this.Position = string.Empty;
			this.MinimumSalaries = string.Empty;
			this.BolsaFamiliaNumber = string.Empty;
			this.ConclusionGrade = string.Empty;
			this.RentValue = string.Empty;
			this.Iptu = string.Empty;
			this.Rooms = string.Empty;
			this.Bedrooms = string.Empty;
			this.Zoning = string.Empty;
			this.HealthType = string.Empty;
			this.HealthClass = string.Empty;

			this.Birthdate = DateTime.MinValue;
			this.HealthStartDate = DateTime.MinValue;
			this.HealthEndDate = DateTime.MinValue;
		}

		public Person (SqliteDataReader reader)
		{
			this.Id = reader.GetInt64 (reader.GetOrdinal ("Id")); 

			// Cadastro
			this.Name = reader.GetString (reader.GetOrdinal ("Name"));
			this.Sex = reader.GetInt64 (reader.GetOrdinal ("Sex"));
			this.Color = reader.GetInt64 (reader.GetOrdinal ("Color"));
			this.Birthdate = reader.GetDateTime (reader.GetOrdinal ("Birthdate"));
			this.Street = reader.GetString (reader.GetOrdinal ("Street"));
			this.Number = reader.GetString (reader.GetOrdinal ("Number"));
			this.Neighborhood = reader.GetString (reader.GetOrdinal ("Neighborhood"));
			this.Cep = reader.GetString (reader.GetOrdinal ("Cep"));

			// Pessoais
			this.ReferenceName = reader.GetString (reader.GetOrdinal ("ReferenceName"));
			this.Relationship = reader.GetInt64 (reader.GetOrdinal ("Relationship"));
			this.FatherName = reader.GetString (reader.GetOrdinal ("FatherName"));
			this.MotherName = reader.GetString (reader.GetOrdinal ("MotherName"));
			this.Rg = reader.GetString (reader.GetOrdinal ("Rg"));
			this.RgExpeditioner = reader.GetString (reader.GetOrdinal ("RgExpeditioner"));
			this.Cpf = reader.GetString (reader.GetOrdinal ("Cpf"));
			this.VoterDocument = reader.GetString (reader.GetOrdinal ("VoterDocument"));
			this.VotingZone = reader.GetString (reader.GetOrdinal ("VotingZone"));
			this.VotingSession = reader.GetString (reader.GetOrdinal ("VotingSession"));
			this.Ctps = reader.GetString (reader.GetOrdinal ("Ctps"));
			this.CtpsSeries = reader.GetString (reader.GetOrdinal ("CtpsSeries"));
			this.CtpsUf = reader.GetString (reader.GetOrdinal ("CtpsUf"));
			this.Email = reader.GetString (reader.GetOrdinal ("Email"));
			this.Phone1 = reader.GetString (reader.GetOrdinal ("Phone1"));
			this.Phone2 = reader.GetString (reader.GetOrdinal ("Phone2"));
			this.Phone3 = reader.GetString (reader.GetOrdinal ("Phone3"));
			this.Nationality = reader.GetString (reader.GetOrdinal ("Nationality"));
			this.Uf = reader.GetString (reader.GetOrdinal ("Uf"));
			this.City = reader.GetString (reader.GetOrdinal ("City"));
			this.RelationshipStatus = reader.GetInt64 (reader.GetOrdinal ("RelationshipStatus"));

			// Ocupação 
			this.OcupationLevel = reader.GetString (reader.GetOrdinal ("OcupationLevel"));

			// Rendimentos
			this.Company = reader.GetString (reader.GetOrdinal ("Company"));
			this.ContractDate = reader.GetDateTime (reader.GetOrdinal ("ContractDate"));
			this.Position = reader.GetString (reader.GetOrdinal ("Position"));
			this.MinimumSalaries = reader.GetString (reader.GetOrdinal ("MinimumSalaries"));
			this.IncomeType = reader.GetInt64 (reader.GetOrdinal ("IncomeType"));
			this.ContractType = reader.GetInt64 (reader.GetOrdinal ("CotractType"));
			this.WorkType = reader.GetInt64 (reader.GetOrdinal ("WorkType"));
			this.Inss = reader.GetBoolean (reader.GetOrdinal ("Inss"));
			this.BolsaFamilia = reader.GetBoolean (reader.GetOrdinal ("BolsaFamilia"));
			this.BolsaFamiliaNumber = reader.GetString (reader.GetOrdinal ("BolsaFamiliaNumber"));

			// Educação
			this.Education = reader.GetInt64 (reader.GetOrdinal ("Education"));
			this.ConclusionGrade = reader.GetString (reader.GetOrdinal ("ConclusionGrade"));

			// Moradia
			this.Rent = reader.GetInt64 (reader.GetOrdinal ("Rent"));
			this.RentValue = reader.GetString (reader.GetOrdinal ("RentValue"));
			this.Iptu = reader.GetString (reader.GetOrdinal ("Iptu"));
			this.HouseLevel = reader.GetInt64 (reader.GetOrdinal ("HouseLevel"));
			this.HouseType = reader.GetInt64 (reader.GetOrdinal ("HouseType"));
			this.ComfortLevel = reader.GetInt64 (reader.GetOrdinal ("ComfortLevel"));
			this.Rooms = reader.GetString (reader.GetOrdinal ("Rooms"));
			this.Bedrooms = reader.GetString (reader.GetOrdinal ("Bedrooms"));
			this.Zoning = reader.GetString (reader.GetOrdinal ("Zoning"));
			this.Water = reader.GetBoolean (reader.GetOrdinal ("Water"));
			this.Bathroom = reader.GetBoolean (reader.GetOrdinal ("Bathroom"));
			this.Floor = reader.GetBoolean (reader.GetOrdinal ("Floor"));
			this.WaterTreatment = reader.GetBoolean (reader.GetOrdinal ("WaterTreatment"));
			this.GarbageTreatment = reader.GetBoolean (reader.GetOrdinal ("GarbageTreatment"));
			this.FloorMaterial = reader.GetInt64 (reader.GetOrdinal ("FloorMaterial"));
			this.WallMaterial = reader.GetInt64 (reader.GetOrdinal ("WallMaterial"));

			// Saúde
			this.HealthType = reader.GetString (reader.GetOrdinal ("HealthType"));
			this.HealthClass = reader.GetString (reader.GetOrdinal ("HealthClass"));
			this.HealthStartDate = reader.GetDateTime (reader.GetOrdinal ("HealthStartDate"));
			this.HealthEndDate = reader.GetDateTime (reader.GetOrdinal ("HealthEndDate"));
		}

		public static Person[] GetAll ()
		{
			var sql = "SELECT * FROM PERSON ORDER BY Name;";
			List<Person> result = new List<Person> ();

			using (var conn = Repository.GetConnection ()) {
				conn.Open ();

				using (var cmd = conn.CreateCommand ()) {
					cmd.CommandText = sql;

					using (var reader = cmd.ExecuteReader ()) {

						while (reader.Read ())
							result.Add(new Person (reader)); 
					}
				}
			}

			return result.ToArray ();
		}

		public static Person Get (long id)
		{
			var sql =  string.Format ("SELECT * FROM PERSON WHERE Id = {0};", id);

			using (var conn = Repository.GetConnection ()) {
				conn.Open ();

				using (var cmd = conn.CreateCommand ()) {
					cmd.CommandText = sql;

					using (var reader = cmd.ExecuteReader ()) {
						if (reader.Read ())
							return new Person (reader); 
						else
							return null;
					}
				}
			}
		}

		public void Delete ()
		{
			var sql = string.Format ("DELETE FROM PERSON WHERE Id = {0};", this.Id);

			using (var conn = Repository.GetConnection ()) {
				conn.Open ();

				using (var cmd = conn.CreateCommand ()) {
					cmd.CommandText = sql;
					cmd.ExecuteNonQuery ();
				}
			}
		}

		void Parameters (SqliteCommand cmd)
		{
			cmd.Parameters.AddWithValue("@Name", this.Name);
			cmd.Parameters.AddWithValue("@Sex", this.Sex);
			cmd.Parameters.AddWithValue("@Color", this.Color);
			cmd.Parameters.AddWithValue("@Birthdate", this.Birthdate);
			cmd.Parameters.AddWithValue("@Street", this.Street);
			cmd.Parameters.AddWithValue("@Number", this.Number);
			cmd.Parameters.AddWithValue("@Neighborhood", this.Neighborhood);
			cmd.Parameters.AddWithValue("@Cep", this.Cep);
			cmd.Parameters.AddWithValue("@ReferenceName", this.ReferenceName);
			cmd.Parameters.AddWithValue("@Relationship", this.Relationship);
			cmd.Parameters.AddWithValue("@FatherName", this.FatherName);
			cmd.Parameters.AddWithValue("@MotherName", this.MotherName);
			cmd.Parameters.AddWithValue("@Rg", this.Rg);
			cmd.Parameters.AddWithValue("@RgExpeditioner", this.RgExpeditioner);
			cmd.Parameters.AddWithValue("@Cpf", this.Cpf);
			cmd.Parameters.AddWithValue("@VoterDocument", this.VoterDocument);
			cmd.Parameters.AddWithValue("@VotingZone", this.VotingZone);
			cmd.Parameters.AddWithValue("@VotingSession", this.VotingSession);
			cmd.Parameters.AddWithValue("@Ctps", this.Ctps);
			cmd.Parameters.AddWithValue("@CtpsSeries", this.CtpsSeries);
			cmd.Parameters.AddWithValue("@CtpsUf", this.CtpsUf);
			cmd.Parameters.AddWithValue("@Email", this.Email);
			cmd.Parameters.AddWithValue("@Phone1", this.Phone1);
			cmd.Parameters.AddWithValue("@Phone2", this.Phone2);
			cmd.Parameters.AddWithValue("@Phone3", this.Phone3);
			cmd.Parameters.AddWithValue("@Nationality", this.Nationality);
			cmd.Parameters.AddWithValue("@Uf", this.Uf);
			cmd.Parameters.AddWithValue("@City", this.City);
			cmd.Parameters.AddWithValue("@RelationshipStatus", this.RelationshipStatus);
			cmd.Parameters.AddWithValue("@OcupationLevel", this.OcupationLevel);
			cmd.Parameters.AddWithValue("@Company", this.Company);
			cmd.Parameters.AddWithValue("@ContractDate", this.ContractDate);
			cmd.Parameters.AddWithValue("@Position", this.Position);
			cmd.Parameters.AddWithValue("@MinimumSalaries", this.MinimumSalaries);
			cmd.Parameters.AddWithValue("@IncomeType", this.IncomeType);
			cmd.Parameters.AddWithValue("@CotractType", this.ContractType);
			cmd.Parameters.AddWithValue("@WorkType", this.WorkType);
			cmd.Parameters.AddWithValue("@Inss", this.Inss);
			cmd.Parameters.AddWithValue("@BolsaFamilia", this.BolsaFamilia);
			cmd.Parameters.AddWithValue("@BolsaFamiliaNumber", this.BolsaFamiliaNumber);
			cmd.Parameters.AddWithValue("@Education", this.Education);
			cmd.Parameters.AddWithValue("@ConclusionGrade", this.ConclusionGrade);
			cmd.Parameters.AddWithValue("@Rent", this.Rent);
			cmd.Parameters.AddWithValue("@RentValue", this.RentValue);
			cmd.Parameters.AddWithValue("@Iptu", this.Iptu);
			cmd.Parameters.AddWithValue("@HouseLevel", this.HouseLevel);
			cmd.Parameters.AddWithValue("@HouseType", this.HouseType);
			cmd.Parameters.AddWithValue("@ComfortLevel", this.ComfortLevel);
			cmd.Parameters.AddWithValue("@Rooms", this.Rooms);
			cmd.Parameters.AddWithValue("@Bedrooms", this.Bedrooms);
			cmd.Parameters.AddWithValue("@Zoning", this.Zoning);
			cmd.Parameters.AddWithValue("@Water", this.Water);
			cmd.Parameters.AddWithValue("@Bathroom", this.Bathroom);
			cmd.Parameters.AddWithValue("@Floor", this.Floor);
			cmd.Parameters.AddWithValue("@WaterTreatment", this.WaterTreatment);
			cmd.Parameters.AddWithValue("@GarbageTreatment", this.GarbageTreatment);
			cmd.Parameters.AddWithValue("@FloorMaterial", this.FloorMaterial);
			cmd.Parameters.AddWithValue("@WallMaterial", this.WallMaterial);
			cmd.Parameters.AddWithValue("@HealthType", this.HealthType);
			cmd.Parameters.AddWithValue("@HealthClass", this.HealthClass);
			cmd.Parameters.AddWithValue("@HealthStartDate", this.HealthStartDate);
			cmd.Parameters.AddWithValue("@HealthEndDate", this.HealthEndDate);
		}

		public void Save ()
		{
			using (var conn = Repository.GetConnection ()) {
				conn.Open ();

				using (var cmd = conn.CreateCommand ()) {

					if (this.Id <= 0) {
						cmd.CommandText = @"INSERT INTO PERSON (
		Name,
		Sex,
		Color,
		Birthdate,
		Street,
		Number,
		Neighborhood,
		Cep,
		ReferenceName,
		Relationship,
		FatherName,
		MotherName,
		Rg,
		RgExpeditioner,
		Cpf,
		VoterDocument,
		VotingZone,
		VotingSession,
		Ctps,
		CtpsSeries,
		CtpsUf,
		Email,
		Phone1,
		Phone2,
		Phone3,
		Nationality,
		Uf,
		City,
		RelationshipStatus,
		OcupationLevel,
		Company,
		ContractDate,
		Position,
		MinimumSalaries,
		IncomeType,
		CotractType,
		WorkType,
		Inss,
		BolsaFamilia,
		BolsaFamiliaNumber,
		Education,
		ConclusionGrade,
		Rent,
		RentValue,
		Iptu,
		HouseLevel,
		HouseType,
		ComfortLevel,
		Rooms,
		Bedrooms,
		Zoning,
		Water,
		Bathroom,
		Floor,
		WaterTreatment,
		GarbageTreatment,
		FloorMaterial,
		WallMaterial,
		HealthType,
		HealthClass,
		HealthStartDate,
		HealthEndDate
) VALUES (
		@Name,
		@Sex,
		@Color,
		@Birthdate,
		@Street,
		@Number,
		@Neighborhood,
		@Cep,
		@ReferenceName,
		@Relationship,
		@FatherName,
		@MotherName,
		@Rg,
		@RgExpeditioner,
		@Cpf,
		@VoterDocument,
		@VotingZone,
		@VotingSession,
		@Ctps,
		@CtpsSeries,
		@CtpsUf,
		@Email,
		@Phone1,
		@Phone2,
		@Phone3,
		@Nationality,
		@Uf,
		@City,
		@RelationshipStatus,
		@OcupationLevel,
		@Company,
		@ContractDate,
		@Position,
		@MinimumSalaries,
		@IncomeType,
		@CotractType,
		@WorkType,
		@Inss,
		@BolsaFamilia,
		@BolsaFamiliaNumber,
		@Education,
		@ConclusionGrade,
		@Rent,
		@RentValue,
		@Iptu,
		@HouseLevel,
		@HouseType,
		@ComfortLevel,
		@Rooms,
		@Bedrooms,
		@Zoning,
		@Water,
		@Bathroom,
		@Floor,
		@WaterTreatment,
		@GarbageTreatment,
		@FloorMaterial,
		@WallMaterial,
		@HealthType,
		@HealthClass,
		@HealthStartDate,
		@HealthEndDate
); SELECT last_insert_rowid();";
						Parameters (cmd);

						this.Id = (long)cmd.ExecuteScalar ();
					} else {
						cmd.CommandText = @"UPDATE PERSON SET 
			Name = @Name,
			Sex = @Sex,
			Color = @Color,
			Birthdate = @Birthdate,
			Street = @Street,
			Number = @Number,
			Neighborhood = @Neighborhood,
			Cep = @Cep,
			ReferenceName = @ReferenceName,
			Relationship = @Relationship,
			FatherName = @FatherName,
			MotherName = @MotherName,
			Rg = @Rg,
			RgExpeditioner = @RgExpeditioner,
			Cpf = @Cpf,
			VoterDocument = @VoterDocument,
			VotingZone = @VotingZone,
			VotingSession = @VotingSession,
			Ctps = @Ctps,
			CtpsSeries = @CtpsSeries,
			CtpsUf = @CtpsUf,
			Email = @Email,
			Phone1 = @Phone1,
			Phone2 = @Phone2,
			Phone3 = @Phone3,
			Nationality = @Nationality,
			Uf = @Uf,
			City = @City,
			RelationshipStatus = @RelationshipStatus,
			OcupationLevel = @OcupationLevel,
			Company = @Company,
			ContractDate = @ContractDate,
			Position = @Position,
			MinimumSalaries = @MinimumSalaries,
			IncomeType = @IncomeType,
			CotractType = @CotractType,
			WorkType = @WorkType,
			Inss = @Inss,
			BolsaFamilia = @BolsaFamilia,
			BolsaFamiliaNumber = @BolsaFamiliaNumber,
			Education = @Education,
			ConclusionGrade = @ConclusionGrade,
			Rent = @Rent,
			RentValue = @RentValue,
			Iptu = @Iptu,
			HouseLevel = @HouseLevel,
			HouseType = @HouseType,
			ComfortLevel = @ComfortLevel,
			Rooms = @Rooms,
			Bedrooms = @Bedrooms,
			Zoning = @Zoning,
			Water = @Water,
			Bathroom = @Bathroom,
			Floor = @Floor,
			WaterTreatment = @WaterTreatment,
			GarbageTreatment = @GarbageTreatment,
			FloorMaterial = @FloorMaterial,
			WallMaterial = @WallMaterial,
			HealthType = @HealthType,
			HealthClass = @HealthClass,
			HealthStartDate = @HealthStartDate,
			HealthEndDate = @HealthEndDate
WHERE Id = @Id";
						cmd.Parameters.AddWithValue ("@Id", this.Id);
						Parameters (cmd);

						cmd.ExecuteNonQuery ();
					}
				}
			}
		}
	}
}

