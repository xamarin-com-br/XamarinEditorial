using System;
using System.Collections.Generic;
using Android.App;
using Android.Views;
using Android.Widget;

namespace eCadCon
{
	public class PersonAdapter : BaseAdapter<Person>, ISectionIndexer
	{
		Person[] items;
		Activity context;

		string[] sections;
		Java.Lang.Object[] sectionsObjects;
		Dictionary<string, int> alphaIndex;

		public PersonAdapter (Activity context, Person[] items) : base()
		{
			this.context = context;
			this.items = items;

			alphaIndex = new Dictionary<string, int>();
			for (int i = 0; i < items.Length; i++) {
				string key;
				if (string.IsNullOrEmpty (items [i].Name))
					key = " ";
				else
					key = items[i].Name.ToUpperInvariant()[0].ToString();
				if (!alphaIndex.ContainsKey(key))
					alphaIndex.Add(key, i);
			}
			sections = new string[alphaIndex.Keys.Count];
			alphaIndex.Keys.CopyTo(sections, 0);

			sectionsObjects = new Java.Lang.Object[sections.Length];
			for (int i = 0; i < sections.Length; i++) {
				sectionsObjects[i] = new Java.Lang.String(sections[i]);
			}
		}

		public override long GetItemId (int position)
		{
			return items[position].Id;
		}

		public override Person this [int position] {  
			get { return items[position]; }
		}

		public override int Count {
			get { return items.Length; }
		}

		public override View GetView (int position, View convertView, ViewGroup parent)
		{
			View view = convertView;
			if (view == null) 
				view = context.LayoutInflater.Inflate (Android.Resource.Layout.SimpleListItem1, null);

			view.FindViewById<TextView> (Android.Resource.Id.Text1).Text = items [position].Name;

			return view;
		}

		#region ISectionIndexer implementation

		public int GetPositionForSection (int section)
		{
			if (section >= sections.Length)
				section = sections.Length - 1;

			return alphaIndex[sections[section]];
		}

		public int GetSectionForPosition (int position)
		{
//			int prevSection = 0;
//			for (int i = 0; i < sections.Length; i++) {
//				if (GetPositionForSection(i) > position && prevSection <= position) {
//					prevSection = i; break;
//				}
//			}
//
//			return prevSection;

			return 1;
		}

		public Java.Lang.Object[] GetSections ()
		{
			return sectionsObjects;
		}

		#endregion
	}
}

