using System;
using Android.App;
using Android.Views;
using Android.Widget;

namespace eCadCon
{
	public class MoradiaFragment : Fragment
	{
		private Spinner rent;
		private EditText rent_value;
		private Spinner house_level;
		private Spinner house_type;
		private Spinner comfort_level;
		private Spinner floor_material;
		private Spinner wall_material;
		private TextView iptu;
		private TextView rooms;
		private TextView bedrooms;
		private TextView zoning;
		private CheckBox water;
		private CheckBox bathroom;
		private CheckBox floor;
		private CheckBox water_treatment;
		private CheckBox garbage_treatment;

		Activity1 main;

		public override Android.Views.View OnCreateView(Android.Views.LayoutInflater inflater,
		                                                Android.Views.ViewGroup container, Android.OS.Bundle savedInstanceState)
		{
			View view = inflater.Inflate(Resource.Layout.MoradiaFragment, container, false);

			rent = view.FindViewById<Spinner> (Resource.Id.rent);

			var rent_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                      Resource.Array.rent_array,
			                                                      Resource.Id.txt_nothing_selected, rent.Prompt);
			rent.Adapter = rent_adapter;
			rent.SetSelection ((int) Repository.Person.Rent);

			rent_value = view.FindViewById<EditText> (Resource.Id.rent_value);
			if (rent.SelectedItem != null) {
				rent_value.Visibility = rent.SelectedItem.ToString() == "Alugada" ? ViewStates.Visible  : ViewStates.Gone;
			} else {
				rent_value.Visibility = ViewStates.Gone;
			}

			rent.ItemSelected += (sender, e) => { 
				if (rent.SelectedItem != null) {
					rent_value.Visibility = rent.SelectedItem.ToString() == "Alugada" ? ViewStates.Visible  : ViewStates.Gone;
				} else {
					rent_value.Visibility = ViewStates.Gone;
				}
			};

			house_level = view.FindViewById<Spinner> (Resource.Id.house_level);

			var house_level_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                     		Resource.Array.house_level_array,
			                                                            Resource.Id.txt_nothing_selected, house_level.Prompt);
			house_level.Adapter = house_level_adapter;
			house_level.SetSelection ((int)Repository.Person.HouseLevel);

			house_type = view.FindViewById<Spinner> (Resource.Id.house_type);

			var house_type_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                      Resource.Array.house_type_array,
			                                                      Resource.Id.txt_nothing_selected, house_type.Prompt);
			house_type.Adapter = house_type_adapter;
			house_type.SetSelection ((int)Repository.Person.HouseType);

			comfort_level = view.FindViewById<Spinner> (Resource.Id.comfort_level);

			var comfort_level_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                      Resource.Array.comfort_level_array,
			                                                               Resource.Id.txt_nothing_selected, comfort_level.Prompt);
			comfort_level.Adapter = comfort_level_adapter;
			comfort_level.SetSelection ((int)Repository.Person.ComfortLevel);

			floor_material = view.FindViewById<Spinner> (Resource.Id.floor_material);

			var floor_material_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                      Resource.Array.floor_material_array,
			                                                                Resource.Id.txt_nothing_selected, floor_material.Prompt);
			floor_material.Adapter = floor_material_adapter;
			floor_material.SetSelection ((int)Repository.Person.FloorMaterial);

			wall_material = view.FindViewById<Spinner> (Resource.Id.wall_material);

			var wall_material_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                      Resource.Array.wall_material_array,
			                                                               Resource.Id.txt_nothing_selected, wall_material.Prompt);
			wall_material.Adapter = wall_material_adapter;
			wall_material.SetSelection ((int)Repository.Person.WallMaterial);

			rent_value = view.FindViewById<EditText> (Resource.Id.rent_value);
			rent_value.Text = Repository.Person.RentValue;

			iptu = view.FindViewById<TextView> (Resource.Id.iptu);
			iptu.Text = Repository.Person.Iptu;

			rooms = view.FindViewById<TextView> (Resource.Id.rooms);
			rooms.Text = Repository.Person.Rooms;

			bedrooms = view.FindViewById<TextView> (Resource.Id.bedrooms);
			bedrooms.Text = Repository.Person.Bedrooms;

			zoning = view.FindViewById<TextView> (Resource.Id.zoning);
			zoning.Text = Repository.Person.Zoning;

			water = view.FindViewById<CheckBox> (Resource.Id.water);
			water.Checked = Repository.Person.Water;

			bathroom = view.FindViewById<CheckBox> (Resource.Id.bathroom);
			bathroom.Checked = Repository.Person.Bathroom;

			floor = view.FindViewById<CheckBox> (Resource.Id.floor);
			floor.Checked = Repository.Person.Floor;

			water_treatment = view.FindViewById<CheckBox> (Resource.Id.water_treatment);
			water_treatment.Checked = Repository.Person.WaterTreatment;

			garbage_treatment = view.FindViewById<CheckBox> (Resource.Id.garbage_treatment);
			garbage_treatment.Checked = Repository.Person.GarbageTreatment;

			return view;
		}

		void Save ()
		{
			Repository.Person.Rent = rent.SelectedItemId + 1;
			Repository.Person.RentValue = rent_value.Text;
			Repository.Person.HouseLevel = house_level.SelectedItemId + 1;
			Repository.Person.HouseType = house_type.SelectedItemId + 1;
			Repository.Person.ComfortLevel = comfort_level.SelectedItemId + 1;
			Repository.Person.FloorMaterial = floor_material.SelectedItemId + 1;
			Repository.Person.WallMaterial = wall_material.SelectedItemId + 1;
			Repository.Person.RentValue = rent_value.Text;
			Repository.Person.Iptu = iptu.Text;
			Repository.Person.Rooms = rooms.Text;
			Repository.Person.Bedrooms = bedrooms.Text;
			Repository.Person.Zoning = zoning.Text;
			Repository.Person.Water = water.Checked;
			Repository.Person.Bathroom = bathroom.Checked;
			Repository.Person.Floor = floor.Checked;
			Repository.Person.WaterTreatment = water_treatment.Checked;
			Repository.Person.GarbageTreatment = garbage_treatment.Checked;
			Repository.Person.Save ();
		}

		public override void OnDestroyView ()
		{	
			Save ();

			main.OnSave = null;

			base.OnDestroyView ();
		}

		public override void OnAttach (Activity activity)
		{
			base.OnAttach (activity);
			main = activity as Activity1;

			main.OnSave = Save;
		}
	}
}

