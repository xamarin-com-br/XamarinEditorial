using System;
using System.Globalization;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace eCadCon
{
	[Activity (Label = "eCadCon", MainLauncher = true)]
	public class Activity1 : ListActivity
	{
		const int BIRTHDATE_DIALOG_ID = 0;	
		const int RENDIMENTO_DIALOG_ID = 1;
		const int SAUDE_START_DIALOG_ID = 2;
		const int SAUDE_END_DIALOG_ID = 3;

		internal EventHandler<DatePickerDialog.DateSetEventArgs> OnBirthdateSet;
		internal EventHandler<DatePickerDialog.DateSetEventArgs> OnContractDateSet;
		internal EventHandler<DatePickerDialog.DateSetEventArgs> OnStartDateSet;
		internal EventHandler<DatePickerDialog.DateSetEventArgs> OnEndDateSet;

		internal delegate DateTime GetDate();
		internal delegate void Save();

		internal GetDate OnGetBirthdate;
		internal GetDate OnGetContractDate;
		internal GetDate OnGetStartDate;
		internal GetDate OnGetEndDate;

		internal Save OnSave;

		IMenuItem insertMenuItem;
		IMenuItem saveMenuItem;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			RequestWindowFeature(WindowFeatures.ActionBar);
			SetContentView (Resource.Layout.Main);

			InitializeActionBar();	

			Repository.GetConnection ();
			// System.IO.File.Delete (Repository.db_path);
			ListAdapter = new PersonAdapter(this, Person.GetAll());
		}

		protected override void OnListItemClick(ListView l, View v, int position, long id)
		{
			Android.Widget.Toast.MakeText(this, "Abrindo", Android.Widget.ToastLength.Short).Show();
			Repository.Person = Person.Get (id);
			ActionBar.SetDisplayHomeAsUpEnabled (true);
			insertMenuItem.SetVisible (false);
			saveMenuItem.SetVisible (true);
			ActionBar.NavigationMode = ActionBarNavigationMode.Tabs;
			var list = FindViewById<ListView> (Android.Resource.Id.List);
			list.Visibility = ViewStates.Gone;
		}

		public override bool OnCreateOptionsMenu(IMenu menu)
		{
			MenuInflater.Inflate(Resource.Menu.ActionItems, menu);
			insertMenuItem = menu.FindItem (Resource.Id.menu_insert);
			saveMenuItem = menu.FindItem (Resource.Id.menu_save);
			saveMenuItem.SetVisible (false);
			return true;
		}

		public override bool OnOptionsItemSelected(IMenuItem item)
		{
			var list = FindViewById<ListView> (Android.Resource.Id.List);

			switch (item.ItemId) {
			case Resource.Id.menu_save:
				if (OnSave != null)
				{
					Android.Widget.Toast.MakeText(this, "Gravando", Android.Widget.ToastLength.Short).Show();
					OnSave ();
				}
				return true;
			case Android.Resource.Id.Home:
				ActionBar.NavigationMode = ActionBarNavigationMode.Standard;
				ActionBar.SetDisplayHomeAsUpEnabled (false);
				insertMenuItem.SetVisible (true);
				saveMenuItem.SetVisible (false);
				Android.Widget.Toast.MakeText(this, "Voltando", Android.Widget.ToastLength.Short).Show();
				ListAdapter = new PersonAdapter(this, Person.GetAll());
				list.Visibility = ViewStates.Visible;
				list.FastScrollEnabled = true;
				return true;
			case Resource.Id.menu_insert:
				Android.Widget.Toast.MakeText(this, "Inserindo", Android.Widget.ToastLength.Short).Show();
				Repository.Person = new Person ();
				ActionBar.SetDisplayHomeAsUpEnabled (true);
				insertMenuItem.SetVisible (false);
				saveMenuItem.SetVisible (true);
				ActionBar.NavigationMode = ActionBarNavigationMode.Tabs;
				list.Visibility = ViewStates.Gone;
				return true;
			case Resource.Id.menu_download:
				var download = new Intent (this, typeof(FileDownloader));
				download.PutExtra ("type", "download");
				StartActivity (download); 
				return true;
			case Resource.Id.menu_upload:
				var upload = new Intent (this, typeof(FileDownloader));
				upload.PutExtra ("type", "upload");
				StartActivity (upload); 
				return true;
			default:
				return base.OnOptionsItemSelected(item);
			}
		}

		private void InitializeActionBar()
		{
			ActionBar.NavigationMode = ActionBarNavigationMode.Standard;
			ActionBar.SetHomeButtonEnabled (true);

			var tab1 = CreateTab<CadastroFragment>("Cadastro");
			ActionBar.AddTab(tab1);

			var tab2 = CreateTab<PessoaisFragment>("Pessoais");
			ActionBar.AddTab(tab2);

			var tab3 = CreateTab<OcupacionalFragment>("Ocupacional");
			ActionBar.AddTab(tab3);

			var tab4 = CreateTab<RendimentosFragment>("Rendimentos");
			ActionBar.AddTab(tab4);

			var tab5 = CreateTab<InstrucaoFragment>("Instrução");
			ActionBar.AddTab(tab5);

			var tab6 = CreateTab<MoradiaFragment>("Moradia");
			ActionBar.AddTab(tab6);

			var tab7 = CreateTab<SaudeFragment>("Saúde");
			ActionBar.AddTab(tab7);

		}

		ActionBar.Tab CreateTab<T>(string title) where T: Fragment, new()
		{
			var newTab = ActionBar.NewTab ();
			newTab.SetTabListener( new TabListener<T>() );
			newTab.SetText(title);

			return newTab;
		}

		protected override Dialog OnCreateDialog (int id)
		{
			DateTime date;

			switch (id) {
			case BIRTHDATE_DIALOG_ID:
				if (OnGetBirthdate != null && OnBirthdateSet != null) {
					date = OnGetBirthdate ();
					return new DatePickerDialog (this, OnBirthdateSet, date.Year, date.Month - 1, date.Day);
				} else {
					return null;
				}
			case RENDIMENTO_DIALOG_ID:
				if (OnGetContractDate != null && OnContractDateSet != null) {
					date = OnGetContractDate ();
					return new DatePickerDialog (this, OnContractDateSet, date.Year, date.Month - 1, date.Day); 
				} else {
					return null;
				}
			case SAUDE_START_DIALOG_ID:
				if (OnGetStartDate != null && OnStartDateSet != null) {
					date = OnGetStartDate ();
					return new DatePickerDialog (this, OnStartDateSet, date.Year, date.Month - 1, date.Day); 
				} else {
					return null;
				}
			case SAUDE_END_DIALOG_ID:
				if (OnGetEndDate != null && OnEndDateSet != null) {
					date = OnGetEndDate ();
					return new DatePickerDialog (this, OnEndDateSet, date.Year, date.Month - 1, date.Day); 
				} else {
					return null;
				}
			default:
				return null;
			}
		} 
	}
}


