using System;
using Android.App;
using Android.Views;
using Android.Widget;

namespace eCadCon
{
	public class OcupacionalFragment : Fragment
	{
		private TextView ocupational_level;

		Activity1 main;

		public override Android.Views.View OnCreateView(Android.Views.LayoutInflater inflater,
		                                                Android.Views.ViewGroup container, Android.OS.Bundle savedInstanceState)
		{
			View view =  inflater.Inflate(Resource.Layout.OcupacionalFragment, container, false);

			ocupational_level = view.FindViewById<TextView> (Resource.Id.ocupational_level);
			ocupational_level.Text = Repository.Person.OcupationLevel;

			return view;
		}

		void Save ()
		{
			Repository.Person.OcupationLevel = ocupational_level.Text;
			Repository.Person.Save ();
		}

		public override void OnDestroyView ()
		{
			Save ();

			main.OnSave = null;

			base.OnDestroyView ();
		}

		public override void OnAttach (Activity activity)
		{
			base.OnAttach (activity);
			main = activity as Activity1;

			main.OnSave = Save;
		}
	}
}

