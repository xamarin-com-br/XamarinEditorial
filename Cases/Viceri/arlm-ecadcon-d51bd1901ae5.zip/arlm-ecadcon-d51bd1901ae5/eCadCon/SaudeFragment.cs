using System;
using Android.App;
using Android.Widget;
using Android.Views;
using System.Globalization;

namespace eCadCon
{
	public class SaudeFragment : Fragment
	{
		private TextView start_date;
		private TextView end_date;
		private TextView health_type;
		private TextView health_class;

		private DateTime date;
		Activity1 main;

		const int SAUDE_START_DIALOG_ID = 2;
		const int SAUDE_END_DIALOG_ID = 3;

		public override Android.Views.View OnCreateView(Android.Views.LayoutInflater inflater,
		                                                Android.Views.ViewGroup container, Android.OS.Bundle savedInstanceState)
		{
			View view = inflater.Inflate(Resource.Layout.SaudeFragment, container, false);

			date = DateTime.Now;

			start_date = view.FindViewById<TextView> (Resource.Id.start_date); 
			start_date.Click += delegate {
				Activity.ShowDialog (SAUDE_START_DIALOG_ID);
			};

			end_date = view.FindViewById<TextView> (Resource.Id.end_date); 
			end_date.Click += delegate {
				Activity.ShowDialog (SAUDE_END_DIALOG_ID);
			};

			start_date.Text = Repository.Person.HealthStartDate == DateTime.MinValue  ? 
				"" : Repository.Person.HealthStartDate.ToString ("dd/MM/yyyy");

			end_date.Text =Repository.Person.HealthEndDate == DateTime.MinValue  ? 
				"" : Repository.Person.HealthEndDate.ToString ("dd/MM/yyyy");

			health_type = view.FindViewById<TextView> (Resource.Id.health_type);
			health_type.Text = Repository.Person.HealthType;

			health_class = view.FindViewById<TextView> (Resource.Id.health_class);
			health_class.Text = Repository.Person.HealthClass;

			return view;

		}

		public override void OnAttach (Activity activity)
		{
			base.OnAttach (activity);

			main = activity as Activity1;

			main.OnStartDateSet = OnStartDateSet;
			main.OnEndDateSet = OnEndDateSet;

			main.OnGetStartDate = GetStartDate;
			main.OnGetEndDate = GetEndDate;

			main.OnSave = Save;
		}

		void Save ()
		{
			Repository.Person.HealthStartDate = GetStartDate ();
			Repository.Person.HealthEndDate = GetEndDate ();
			Repository.Person.HealthType = health_type.Text;
			Repository.Person.HealthClass = health_class.Text;
			Repository.Person.Save ();
		}

		public override void OnDestroyView ()
		{
			Save ();

			main.OnStartDateSet = null;
			main.OnEndDateSet = null;

			main.OnGetStartDate = null;
			main.OnGetEndDate = null;

			main.OnSave = null;

			base.OnDestroyView ();
		}


		public void OnStartDateSet (object sender, DatePickerDialog.DateSetEventArgs e)
		{
			start_date.Text = e.Date.ToString ("dd/MM/yyyy");
		}

		public void OnEndDateSet (object sender, DatePickerDialog.DateSetEventArgs e)
		{
			end_date.Text = e.Date.ToString ("dd/MM/yyyy");
		}

		public DateTime GetStartDate() {
			if (string.IsNullOrEmpty (start_date.Text)) {
				date = DateTime.Now;
			} else {
				date = DateTime.ParseExact(start_date.Text, "dd/MM/yyyy", DateTimeFormatInfo.CurrentInfo);
			}
			return date;
		}

		public DateTime GetEndDate() {
			if (string.IsNullOrEmpty (end_date.Text)) {
				date = DateTime.Now;
			} else {
				date = DateTime.ParseExact (end_date.Text, "dd/MM/yyyy", DateTimeFormatInfo.CurrentInfo);
			}
			return date;
		}
	}
}

