using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.Database;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace eCadCon
{
	public class NothingSelectedSpinnerAdapter : BaseAdapter, ISpinnerAdapter, IListAdapter
	{

		protected const int EXTRA = 1;
		protected ISpinnerAdapter adapter;
		protected Context context;
		protected int nothingSelectedLayout;
		protected int nothingSelectedDropdownLayout;
		protected LayoutInflater layoutInflater;

		public NothingSelectedSpinnerAdapter (ISpinnerAdapter spinnerAdapter, int nothingSelectedLayout, Context context) :
			this (spinnerAdapter, nothingSelectedLayout, -1, context)
		{
		}

		public NothingSelectedSpinnerAdapter (ISpinnerAdapter spinnerAdapter,  
		                                      int nothingSelectedLayout, int nothingSelectedDropdownLayout, Context context)
		{
			this.adapter = spinnerAdapter;
			this.context = context;
			this.nothingSelectedLayout = nothingSelectedLayout;
			this.nothingSelectedDropdownLayout = nothingSelectedDropdownLayout;
			layoutInflater = LayoutInflater.From (context);
		}

		public NothingSelectedSpinnerAdapter (Context context, int nothingSelectedLayout,
		                                      int textArrayResId, int componentId, string text) :
			this(null, nothingSelectedLayout, -1, context)
		{
			var arrayAdapter = ArrayAdapter.CreateFromResource (context, textArrayResId, Android.Resource.Layout.SimpleSpinnerItem);
			arrayAdapter.SetDropDownViewResource (Android.Resource.Layout.SimpleSpinnerDropDownItem);

			this.adapter = arrayAdapter;
			this.nothingSelectedLayout = nothingSelectedLayout;
			this.ComponentId = componentId;
			this.Text = text;
		}

		public int? ComponentId { get; set; }

		public int? StringResourceId { get; set; }

		public string Text { get; set; }

		public override View GetView (int position, View convertView, ViewGroup parent)
		{
			if (position == 0) {
				return GetNothingSelectedView (parent);
			}
			return adapter.GetView (position - EXTRA, null, parent);
		}

		void SetupView (View view)
		{
			if (ComponentId != null) {
				TextView text = view.FindViewById<TextView> ((int)ComponentId);

				if (view != null) {
					if (StringResourceId != null) {
						Android.Content.Res.Resources res = context.Resources;
						text.Text = res.GetString ((int)StringResourceId);
					}
					else
						if (Text != null) {
							text.Text = Text;
						}
				}
			}
		}

		protected View GetNothingSelectedView (ViewGroup parent)
		{
			View view = layoutInflater.Inflate (nothingSelectedLayout, parent, false);

			SetupView (view);

			return view;
		}

		public override View GetDropDownView (int position, View convertView, ViewGroup parent)
		{
			// BUG! Vote to fix!! http://code.google.com/p/android/issues/detail?id=17128 - Spinner does not support multiple view types
			if (position == 0) {
				return nothingSelectedDropdownLayout == -1 ? new View (context) : GetNothingSelectedDropdownView (parent);
			}

			return adapter.GetDropDownView (position - EXTRA, null, parent);  // could re-use the convertView if possible, utilize setTag...
		}

		protected View GetNothingSelectedDropdownView (ViewGroup parent)
		{
			View view = layoutInflater.Inflate (nothingSelectedDropdownLayout, parent, false);

			SetupView (view);

			return view;
		}

		public override int Count {
			get {
				int count = adapter.Count;
				return count == 0 ? 0 : count + EXTRA;
			}
		}

		public override Java.Lang.Object GetItem (int position)
		{
			return position == 0 ? null : adapter.GetItem (position - EXTRA);
		}

		public override int GetItemViewType (int position)
		{
			// doesn't work!! Vote to Fix! http://code.google.com/p/android/issues/detail?id=17128 - Spinner does not support multiple view types
			// This method determines what is the convertView, this should return 1 for pos 0 or return 0 otherwise. 
			return position == 0 ? GetViewTypeCount () - EXTRA : adapter.GetItemViewType (position - EXTRA);
		}

		public int GetViewTypeCount ()
		{
			return adapter.ViewTypeCount + EXTRA;
		}

		public override long GetItemId (int position)
		{
			return adapter.GetItemId (position - EXTRA);
		}

		public bool AsStableIds ()
		{
			return adapter.HasStableIds;
		}

		public override bool IsEmpty {
			get {
				return adapter.IsEmpty;
			}
		}

		public override void RegisterDataSetObserver (DataSetObserver observer)
		{
			adapter.RegisterDataSetObserver (observer);
		}

		public override void UnregisterDataSetObserver (DataSetObserver observer)
		{
			adapter.UnregisterDataSetObserver (observer);
		}

		public override bool AreAllItemsEnabled ()
		{
			return false;
		}

		public override bool IsEnabled (int position)
		{
			return position == 0 ? false : true; // don't allow the 'nothing selected' item to be picked
		}
	}
}
