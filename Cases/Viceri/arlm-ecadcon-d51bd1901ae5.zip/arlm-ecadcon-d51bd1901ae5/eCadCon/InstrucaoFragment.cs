using System;
using Android.App;
using Android.Views;
using Android.Widget;

namespace eCadCon
{
	public class InstrucaoFragment : Fragment
	{
		private Spinner education;
		private TextView conclusion_grade;

		Activity1 main;

		public override Android.Views.View OnCreateView(Android.Views.LayoutInflater inflater,
		                                                Android.Views.ViewGroup container, Android.OS.Bundle savedInstanceState)
		{
			View view = inflater.Inflate(Resource.Layout.InstrucaoFragment, container, false);

			education = view.FindViewById<Spinner> (Resource.Id.education);

			var education_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                           Resource.Array.education_array,
			                                                           Resource.Id.txt_nothing_selected, education.Prompt);
			education.Adapter = education_adapter;
			education.SetSelection ((int) Repository.Person.Education);

			conclusion_grade = view.FindViewById<TextView> (Resource.Id.conclusion_grade);
			conclusion_grade.Text = Repository.Person.ConclusionGrade;

			return view;
		}

		void Save ()
		{
			Repository.Person.Education = education.SelectedItemId + 1;
			Repository.Person.ConclusionGrade = conclusion_grade.Text;
			Repository.Person.Save ();
		}

		public override void OnDestroyView ()
		{
			Save ();

			main.OnSave = null;

			base.OnDestroyView ();
		}

		public override void OnAttach (Activity activity)
		{
			base.OnAttach (activity);
			main = activity as Activity1;

			main.OnSave = Save;
		}
	}
}

