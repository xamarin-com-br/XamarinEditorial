using System;
using Android.App;
using Android.Widget;
using Android.Views;

namespace eCadCon
{
	public class PessoaisFragment: Fragment
	{
		private Spinner relationship;
		private Spinner relationship_status;
		private TextView reference_name;
		private TextView father_name;
		private TextView mother_name;
		private TextView rg;
		private TextView rg_expeditioner;
		private TextView cpf;
		private TextView voter_document;
		private TextView voting_zone;
		private TextView voting_session;
		private TextView ctps;
		private TextView ctps_series;
		private TextView ctps_uf;
		private TextView email;
		private TextView phone1;
		private TextView phone2;
		private TextView phone3;
		private TextView nationality;
		private TextView uf;
		private TextView city;

		Activity1 main;

		public override Android.Views.View OnCreateView(Android.Views.LayoutInflater inflater,
		                                                Android.Views.ViewGroup container, Android.OS.Bundle savedInstanceState)
		{
			View view = inflater.Inflate(Resource.Layout.PessoaisFragment, container, false);

			relationship = view.FindViewById<Spinner> (Resource.Id.relationship);

			var relationship_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                       Resource.Array.relationship_array,
			                                                              Resource.Id.txt_nothing_selected, relationship.Prompt);
			relationship.Adapter = relationship_adapter;
			relationship.SetSelection((int) Repository.Person.Relationship);

			relationship_status = view.FindViewById<Spinner> (Resource.Id.relationship_status);

			var relationship_status_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                                     Resource.Array.relationship_status_array,
			                                                       Resource.Id.txt_nothing_selected, relationship_status.Prompt);
			relationship_status.Adapter = relationship_status_adapter;
			relationship_status.SetSelection((int)Repository.Person.RelationshipStatus);


			reference_name = view.FindViewById<TextView> (Resource.Id.reference_name);
			reference_name.Text = Repository.Person.ReferenceName;

			father_name =view.FindViewById<TextView> (Resource.Id.father_name);
			father_name.Text = Repository.Person.FatherName;

			mother_name = view.FindViewById<TextView> (Resource.Id.mother_name);
			mother_name.Text = Repository.Person.MotherName;

			rg = view.FindViewById<TextView> (Resource.Id.rg);
			rg.Text = Repository.Person.Rg;

			rg_expeditioner = view.FindViewById<TextView> (Resource.Id.rg_expeditioner);
			rg_expeditioner.Text = Repository.Person.RgExpeditioner;

			cpf = view.FindViewById<TextView> (Resource.Id.cpf);
			cpf.Text = Repository.Person.Cpf;

			voter_document = view.FindViewById<TextView> (Resource.Id.voter_document);
			voter_document.Text = Repository.Person.VoterDocument;

			voting_zone = view.FindViewById<TextView> (Resource.Id.voting_zone);
			voting_zone.Text = Repository.Person.VotingZone;

			voting_session = view.FindViewById<TextView> (Resource.Id.voting_session);
			voting_session.Text = Repository.Person.VotingSession;

			ctps = view.FindViewById<TextView> (Resource.Id.ctps);
			ctps.Text = Repository.Person.Ctps;

			ctps_series = view.FindViewById<TextView> (Resource.Id.ctps_series);
			ctps_series.Text = Repository.Person.CtpsSeries;

			ctps_uf = view.FindViewById<TextView> (Resource.Id.ctps_uf);
			ctps_uf.Text = Repository.Person.CtpsUf;

			email = view.FindViewById<TextView> (Resource.Id.email);
			email.Text = Repository.Person.Email;

			phone1 = view.FindViewById<TextView> (Resource.Id.phone1);
			phone1.Text = Repository.Person.Phone1;

			phone2 = view.FindViewById<TextView> (Resource.Id.phone2);
			phone2.Text = Repository.Person.Phone2;

			phone3 = view.FindViewById<TextView> (Resource.Id.phone3);
			phone3.Text = Repository.Person.Phone3;

			nationality = view.FindViewById<TextView> (Resource.Id.nationality);
			nationality.Text = Repository.Person.Nationality;

			uf = view.FindViewById<TextView> (Resource.Id.uf);
			uf.Text = Repository.Person.Uf;

			city = view.FindViewById<TextView> (Resource.Id.city);
			city.Text = Repository.Person.City;

			return view;
		}

		void Save ()
		{
			Repository.Person.ReferenceName = reference_name.Text;
			Repository.Person.Relationship = relationship.SelectedItemId + 1;
			Repository.Person.FatherName = father_name.Text;
			Repository.Person.MotherName = mother_name.Text;
			Repository.Person.Rg = rg.Text;
			Repository.Person.RgExpeditioner = rg_expeditioner.Text;
			Repository.Person.Cpf = cpf.Text;
			Repository.Person.VoterDocument = voter_document.Text;
			Repository.Person.VotingZone = voting_zone.Text;
			Repository.Person.VotingSession = voting_session.Text;
			Repository.Person.Ctps = ctps.Text;
			Repository.Person.CtpsSeries = ctps_series.Text;
			Repository.Person.CtpsUf = ctps_uf.Text;
			Repository.Person.Email = email.Text;
			Repository.Person.Phone1 = phone1.Text;
			Repository.Person.Phone2 = phone2.Text;
			Repository.Person.Phone3 = phone3.Text;
			Repository.Person.Nationality = nationality.Text;
			Repository.Person.Uf = uf.Text;
			Repository.Person.City = city.Text;
			Repository.Person.RelationshipStatus = relationship_status.SelectedItemId + 1;
			Repository.Person.Save ();
		}

		public override void OnDestroyView ()
		{
			Save ();

			main.OnSave = null;

			base.OnDestroyView ();
		}

		public override void OnAttach (Activity activity)
		{
			base.OnAttach (activity);
			main = activity as Activity1;

			main.OnSave = Save;
		}
	}
}

