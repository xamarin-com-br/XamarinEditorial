using System;
using Android.App;
using Android.Widget;
using Android.Views;
using Android.Content;
using System.Globalization;

namespace eCadCon
{
	public class CadastroFragment: Fragment
	{
		private TextView birthdateDisplay;
		private Spinner sex_spinner;
		private Spinner color_spinner;
		private TextView name;
		private TextView street;
		private TextView number;
		private TextView neighborhood;
		private TextView cep;

		private DateTime birthdate;

		Activity1 main;
		const int BIRTHDATE_DIALOG_ID = 0;

		public override View OnCreateView (Android.Views.LayoutInflater inflater,
		                                  Android.Views.ViewGroup container, Android.OS.Bundle savedInstanceState)
		{
			View view = inflater.Inflate (Resource.Layout.CadastroFragment, container, false);

			birthdateDisplay = view.FindViewById<TextView> (Resource.Id.birth_date); 
			birthdateDisplay.Click += delegate {
				Activity.ShowDialog (BIRTHDATE_DIALOG_ID);
			};

			birthdateDisplay.Text = Repository.Person.Birthdate == DateTime.MinValue  ? 
				"" : Repository.Person.Birthdate.ToString ("dd/MM/yyyy");

			sex_spinner = view.FindViewById<Spinner> (Resource.Id.sex);

			var sex_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                     Resource.Array.sex_array,
			                                                     Resource.Id.txt_nothing_selected, sex_spinner.Prompt);
			sex_spinner.Adapter = sex_adapter;
			sex_spinner.SetSelection((int) Repository.Person.Sex);

			color_spinner = view.FindViewById<Spinner> (Resource.Id.color);

			var color_adapter = new NothingSelectedSpinnerAdapter (view.Context, Resource.Layout.NothingSelectedLayout,
			                                                       Resource.Array.color_array,
			                                                       Resource.Id.txt_nothing_selected, color_spinner.Prompt);
			color_spinner.Adapter = color_adapter;
			color_spinner.SetSelection((int) Repository.Person.Color);

			name = view.FindViewById<TextView> (Resource.Id.name);
			name.Text = Repository.Person.Name;

			street = view.FindViewById<TextView> (Resource.Id.street);
			street.Text = Repository.Person.Street;

			number = view.FindViewById<TextView> (Resource.Id.number);
			number.Text = Repository.Person.Number;

			neighborhood = view.FindViewById<TextView> (Resource.Id.neighborhood);
			neighborhood.Text = Repository.Person.Neighborhood;

			cep = view.FindViewById<TextView> (Resource.Id.cep);
			cep.Text = Repository.Person.Cep;

			return view;
		}

		public override void OnAttach (Activity activity)
		{
			base.OnAttach (activity);
			main = activity as Activity1;

			main.OnBirthdateSet = OnBirthdateSet;
			main.OnGetBirthdate = GetDate;
			main.OnSave = Save;
		}

		void Save ()
		{
			Repository.Person.Birthdate = GetDate ();
			Repository.Person.Color = color_spinner.SelectedItemId + 1;
			Repository.Person.Sex = sex_spinner.SelectedItemId + 1;
			Repository.Person.Name = name.Text;
			Repository.Person.Street = street.Text;
			Repository.Person.Number = number.Text;
			Repository.Person.Neighborhood = neighborhood.Text;
			Repository.Person.Cep = cep.Text;
			Repository.Person.Save ();
		}

		public override void OnDestroyView ()
		{
			Save ();

			main.OnBirthdateSet = null;
			main.OnGetBirthdate = null;
			main.OnSave = null;

			base.OnDestroyView ();
		}

		public void OnBirthdateSet (object sender, DatePickerDialog.DateSetEventArgs e)
		{
			birthdateDisplay.Text = e.Date.ToString ("dd/MM/yyyy");
		}

		public DateTime GetDate ()
		{
			if (string.IsNullOrEmpty (birthdateDisplay.Text)) {
				birthdate = DateTime.Now;
			} else {
				birthdate = DateTime.ParseExact (birthdateDisplay.Text, "dd/MM/yyyy", DateTimeFormatInfo.CurrentInfo);
			}
			return birthdate;
		}
	}
}

